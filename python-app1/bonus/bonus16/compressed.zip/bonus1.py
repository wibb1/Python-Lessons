text = input("Enter a title: \n")
length = len(text)
print("The length of the title: ", length)
